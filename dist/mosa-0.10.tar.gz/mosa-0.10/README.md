Laboratoire de recherche en mobilité et sport adapté
====================================================

This module provides functions and classes for the Mobility and Adaptive
Sports Research Lab in Montreal. While this code is open and is free to be
shared, it is developed for our own private use.

If you are looking for other code by our lab, you may be happy with these
public packages:

    - Kinetics Toolkit (https://github.com/felixchenier/kineticstoolkit)
    - Limited Interaction (https://github.com/felixchenier/limitedinteraction)

