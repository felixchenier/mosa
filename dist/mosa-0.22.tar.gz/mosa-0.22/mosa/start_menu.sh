conda activate mosa
python -c 'import mosa; mosa.start_menu()'
